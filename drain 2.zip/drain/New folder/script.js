document.addEventListener("DOMContentLoaded", function () {
  const chains = document.querySelectorAll(".chain");
  const claimButton = document.querySelector(".claim-box button");
  const popup = document.getElementById("wallet-popup");
  const wallets = document.querySelectorAll(".wallet");
  let selectedChain = null;

  // Detect platform
  const isAndroid = /android/i.test(navigator.userAgent);
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);

  // Chain selection
  chains.forEach(chain => {
    chain.addEventListener("click", () => {
      chains.forEach(c => c.classList.remove("selected"));
      chain.classList.add("selected");
      selectedChain = chain.dataset.chain;
    });
  });

  // Claim button click
  claimButton.addEventListener("click", () => {
    if (!selectedChain) {
      alert("Please select a chain before claiming.");
    } else {
      popup.classList.remove("hidden"); // Show wallet popup
    }
  });

  // Wallet selection with deep linking + fallback
  wallets.forEach(wallet => {
    wallet.addEventListener("click", () => {
      const walletName = wallet.textContent.trim().toLowerCase();

      const deepLinks = {
        phantom: "phantom://",
        solflare: "solflare://",
        metamask: "metamask://",
        backpack: "backpack://",
        trust: "trust://",
        ctrl: "ctrlwallet://",
        coinbase: "cbwallet://",
        bitget: "bitget://",
        glow: "glow://"
      };

      const fallbackLinks = {
        phantom: {
          ios: "https://apps.apple.com/app/phantom-wallet/id1598432977",
          android: "https://play.google.com/store/apps/details?id=app.phantom"
        },
        solflare: {
          ios: "https://apps.apple.com/app/solflare-wallet/id1580910231",
          android: "https://play.google.com/store/apps/details?id=com.solflare.mobile"
        },
        metamask: {
          ios: "https://apps.apple.com/app/metamask/id1438144202",
          android: "https://play.google.com/store/apps/details?id=io.metamask"
        },
        backpack: {
          ios: "https://apps.apple.com/app/backpack-wallet/id6449434385",
          android: "https://play.google.com/store/apps/details?id=com.backpack"
        },
        trust: {
          ios: "https://apps.apple.com/app/trust-crypto-bitcoin-wallet/id1288339409",
          android: "https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp"
        },
        ctrl: {
          ios: "https://apps.apple.com/app/ctrl-wallet/id6467713941",
          android: "https://play.google.com/store/apps/details?id=com.ctrlwallet"
        },
        coinbase: {
          ios: "https://apps.apple.com/app/coinbase-buy-bitcoin-eth/id886427730",
          android: "https://play.google.com/store/apps/details?id=com.coinbase.android"
        },
        bitget: {
          ios: "https://apps.apple.com/app/bitget/id1399336091",
          android: "https://play.google.com/store/apps/details?id=com.bitget.exchange"
        },
        glow: {
          ios: "https://apps.apple.com/app/glow-wallet/id6449434385",
          android: "https://play.google.com/store/apps/details?id=com.glowwallet"
        }
      };

      const deepLink = deepLinks[walletName];
      const fallback = fallbackLinks[walletName];

      if (deepLink) {
        window.location.href = deepLink;

        // Fallback after 1.5 seconds
        setTimeout(() => {
          if (fallback) {
            const storeLink = isIOS ? fallback.ios : isAndroid ? fallback.android : null;
            if (storeLink) {
              window.location.href = storeLink;
            }
          }
        }, 1500);
      } else {
        alert(`No deep link available for ${walletName}`);
      }

      popup.classList.add("hidden");
    });
  });
});
